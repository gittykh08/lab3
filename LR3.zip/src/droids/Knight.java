package droids;

public class Knight extends Droid {

    public Knight(int numb) {
        super("Knight " + numb, 120, 20);
    }

}
