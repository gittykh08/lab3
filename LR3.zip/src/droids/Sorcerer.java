package droids;

public class Sorcerer extends Droid {
    public Sorcerer(int numb) {
        super("Sorcerer " + numb, 80, 40);
    }
}
