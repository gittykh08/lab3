package droids;

public class Archer extends Droid{

    public Archer(int numb) {
        super("Archer " + numb, 100, 30);
    }
}
